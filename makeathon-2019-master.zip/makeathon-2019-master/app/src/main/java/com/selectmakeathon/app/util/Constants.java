package com.selectmakeathon.app.util;

public class Constants {

    public static final String PREF_PHONE_NUMBER = "com.selectmakeathon.app.PREF_PHONE_NUMBER";
    public static final String PREF_USER_ID = "com.selectmakeathon.app.PREF_USER_ID";
    public static final String PREF_IS_LOGGED_IN = "com.selectmakeathon.app.PREF_IS_LOGGED_IN";

}
