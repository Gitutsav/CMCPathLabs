package com.selectmakeathon.app.ui.onboarding;

public class OnboardingActivity {
}
