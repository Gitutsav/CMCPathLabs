package com.utsavgupta.abhinay;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.util.ArrayList;
import java.util.List;

import technolifestyle.com.imageslider.FlipperLayout;
import technolifestyle.com.imageslider.FlipperView;

import static com.facebook.FacebookSdk.getApplicationContext;


public class course extends Fragment {
    private FlipperLayout flipperLayout;RecyclerView recyclerView,subjects_recycler_view;
   // private static final String TAG = "MainActivity";

    //vars
    private ArrayList<String> subjects = new ArrayList<>();
    private ArrayList<String> mNames = new ArrayList<>();
    private ArrayList<String> mImageUrls = new ArrayList<>();
    private ArrayList<String> embedcode = new ArrayList<>();
    private ArrayList<String> description = new ArrayList<>();
    private ArrayList<String> _ids = new ArrayList<>();
    private ArrayList<String> names = new ArrayList<>();
    private ArrayList<Integer> _vs = new ArrayList<>();
    private ArrayList<String> createds = new ArrayList<>();
    private ArrayList<String> keys = new ArrayList<>();
    private ArrayList<String> baseUrls = new ArrayList<>();

    private Context mContext;
    private String status;

    public course() {
        // Required empty public constructor
    }

    public static course newInstance(String param1, String param2) {
        course fragment = new course();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        mContext = getContext();
        View view= inflater.inflate(R.layout.fragment_course, container,false);

        flipperLayout = (FlipperLayout) view.findViewById(R.id.vvpflipper_layout);
        recyclerView =(RecyclerView) view.findViewById(R.id.recyclerView);
        subjects_recycler_view =(RecyclerView) view.findViewById(R.id.subjects);
        initsubjects();
        setLayout();
        //getImages();
        new JSONTask().execute();
        return view;
    }
    private void setLayout() {
        String url[] = new String[]{
                "https://s3.ap-south-1.amazonaws.com/penpencil/225781ad-ce48-4425-a786-9c2d48f8d02f.jpg",
                "https://s3.ap-south-1.amazonaws.com/penpencil/60b3e865-42b7-430c-9884-865e67bf6acf.jpg",
                "https://s3.ap-south-1.amazonaws.com/penpencil/63031493-b6da-4d1c-9d3f-bf273d99f38c.jpg"
        };
       /* Resources res = getResources();
        Drawable drawable1 = res.getDrawable(R.drawable.hell);
        // int drwint=Integer.parseInt(drawable1.toString());
        Drawable drawable2 = res.getDrawable(R.drawable.met);
        //  int drwint2=Integer.parseInt(drawable2.toString());
        Drawable drawable3 = res.getDrawable(R.drawable.moto);
        //   int drwint3=Integer.parseInt(drawable3.toString());
        int drw[]={R.drawable.a,R.drawable.b,R.drawable.c};*/
        for (int i = 0; i < 3; i++) {
            FlipperView view = new FlipperView(mContext);
            view.setImageUrl(url[i])
                    .setDescription("");
           /* Picasso.with(getContext())
                    .load(url[i])
                    .placeholder(R.drawable.ic_launcher_background)
                    .into(iv_youtube_thumnail);*/
            flipperLayout.addFlipperView(view);
            view.setOnFlipperClickListener(new FlipperView.OnFlipperClickListener() {
                @Override
                public void onFlipperClick(FlipperView flipperView) {

                }
            });
        }
    }
    private void initsubjects(){
        subjects.add("Maths");
        subjects.add("English");
        subjects.add("Reasoning");
        subjects.add("GS");
        LinearLayoutManager layoutManager = new LinearLayoutManager(mContext, LinearLayoutManager.HORIZONTAL, false);

        subjects_recycler_view.setLayoutManager(layoutManager);
        subjectsAdapter adapter = new subjectsAdapter(mContext, subjects);
        subjects_recycler_view.setAdapter(adapter);
    }
    private void getImages(){
       // Log.d(TAG, "initImageBitmaps: preparing bitmaps.");

        mImageUrls.add("https://c1.staticflickr.com/5/4636/25316407448_de5fbf183d_o.jpg");
        mNames.add("Havasu Falls");

        mImageUrls.add("https://i.redd.it/tpsnoz5bzo501.jpg");
        mNames.add("Trondheim");

        mImageUrls.add("https://i.redd.it/qn7f9oqu7o501.jpg");
        mNames.add("Portugal");

        mImageUrls.add("https://i.redd.it/j6myfqglup501.jpg");
        mNames.add("Rocky Mountain National Park");


        mImageUrls.add("https://i.redd.it/0h2gm1ix6p501.jpg");
        mNames.add("Mahahual");

        mImageUrls.add("https://i.redd.it/k98uzl68eh501.jpg");
        mNames.add("Frozen Lake");


        mImageUrls.add("https://i.redd.it/glin0nwndo501.jpg");
        mNames.add("White Sands Desert");

        mImageUrls.add("https://i.redd.it/obx4zydshg601.jpg");
        mNames.add("Austrailia");

        mImageUrls.add("https://i.imgur.com/ZcLLrkY.jpg");
        mNames.add("Washington");



    }
    private void initRecyclerView(){
        // Log.d(TAG, "initRecyclerView: init recyclerview");

        LinearLayoutManager layoutManager = new LinearLayoutManager(mContext, LinearLayoutManager.HORIZONTAL, false);

        recyclerView.setLayoutManager(layoutManager);
        RecyclerViewAdapter adapter = new RecyclerViewAdapter(mContext, mNames, mImageUrls,embedcode,description);
        recyclerView.setAdapter(adapter);
    }
    public class JSONTask extends AsyncTask<String, String, String> {

        @Override
        protected String doInBackground(String... params) {
            HttpURLConnection connection = null;
            BufferedReader reader = null;


            try {
                HttpClient httpClient = new DefaultHttpClient();
                // Creating HTTP Post

                HttpGet httpPost = new HttpGet("https://api-dev.penpencil.xyz/v1/web-preference/5bb72f09d7de500de0338d00");
//httpPost.setHeader();
                //List<NameValuePair> nameValuePair = new ArrayList<NameValuePair>(1);
                // nameValuePair.add(new BasicNameValuePair("otp", otpp));
                // Url Encoding the POST parameters

                // Making HTTP Request
                try {
                    HttpResponse response = httpClient.execute(httpPost);
                    String responseBody = EntityUtils.toString(response.getEntity());
                    JSONObject obj = new JSONObject(responseBody);
                    JSONObject data=obj.getJSONObject("data");
                    JSONObject videoGallery=data.getJSONObject("videoGallery");
                    JSONArray videoUrls=videoGallery.getJSONArray("videoUrls");
                    for(int i=0;i<videoUrls.length();i++)
                    {
                        JSONObject object=videoUrls.getJSONObject(i);
                        String name=object.getString("name");
                        String image=object.getString("image");
                        String embedCode=object.getString("embedCode");
                        String descriptio=object.getString("description");
                        mNames.add(name);
                        mImageUrls.add(image);
                        embedcode.add(embedCode);
                        description.add(descriptio);

                        }
                    JSONObject banner=data.getJSONObject("banner");
                    JSONArray images=videoGallery.getJSONArray("images");
                    for(int i=0;i<images.length();i++)
                    {
                        JSONObject object=videoUrls.getJSONObject(i);
                        String _id=object.getString("_id");
                        String baseUrl=object.getString("baseUrl");
                        String name=object.getString("name");
                        String key=object.getString("key");
                        String created=object.getString("created");
                        int _v=object.getInt("_v");
                        _ids.add(_id);
                        baseUrls.add(baseUrl);
                        names.add(name);
                        keys.add(key);
                        createds.add(created);
                        _vs.add(_v);

                    }
                    status = obj.getString("success");

                    return responseBody;

                    // writing response to log
                    // String abc = "124" + status_o + usersCount+website+roles;
                    //Toast.makeText(getApplicationContext(), abc + "1111", Toast.LENGTH_LONG).show();
                    //dialog.cancel();
                    //Log.d("Http Response:", status + "123+abc");
                } catch (ClientProtocolException e) {
                    // writing exception to log
                    e.printStackTrace();
                } catch (IOException e) {
                    // writing exception to log
                    e.printStackTrace();

                } catch (JSONException e) {
                    e.printStackTrace();
                }

                return status;


            }
            finally {
                if (connection != null) {
                    connection.disconnect();
                }
                try {

                    if (reader != null) {
                        reader.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        }


        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            /*Toast.makeText(getApplicationContext(),primaryNumber+username+emailg+created+exams+_id+created_p+wallet+
                    dateOfBirth+phones+address+primary+roles
                    +status_o+usersCount+id_o+website+name+enrollmentType+primarycontact_o+_v
                    +rejectionComments+phones_o+created_o,Toast.LENGTH_SHORT).show();*/
         Toast.makeText(mContext,s,Toast.LENGTH_LONG).show();
            initRecyclerView();
           /* if (s.equals("true")) {
                dialog.cancel();

                SharedPreferences.Editor editor = getSharedPreferences("login_data2", MODE_PRIVATE).edit();
                editor.putString("access_token", access_token);
                editor.putString("status_u",status_u);
                // editor.putBoolean("user_isStudent",is_student);
                editor.putString("user_id",idg);
                editor.putString("user_firstName",firstName);
                editor.putString("user_primaryNumber",primaryNumber);
                editor.putString("user_username",username);
                editor.putString("user_email",emailg);
                editor.putString("user_created",created);
                editor.putString("exams", String.valueOf(exams));
                editor.putString("profile_id",_id);
                editor.putString("profile_created",created_p);
                editor.putString("profile_board",board);
                editor.putString("profile_class",class_p);
                editor.putString("profile_language",language);
                editor.putString("profile_lastLoginAt",lastLoginAt);
                editor.putString("profile_programId",programId);
                editor.putString("profile_wallet", String.valueOf(wallet));
                editor.putString("dateOfBirth",dateOfBirth);
                editor.putString("phones", String.valueOf(phones));
                editor.putString("address",address);
                editor.putString("primary",primary);
                editor.putString("organization_status",status_o);
                //editor.putString("status","");
                editor.putString("organization_usersCount", String.valueOf(usersCount));
                editor.putString("organization_id",id_o);
                editor.putString("organization_website",website);
                editor.putString("organization_name",name);
                editor.putString("organization_enrolmentType",enrollmentType);
                editor.putString("organization_primaryContact_id",primaryNumber);
                editor.putString("organization_rejectionComments", String.valueOf(rejectionComments));
                editor.putString("organization_phones", String.valueOf(phones_o));
                editor.putString("organization_created",created_o);
                editor.putString("roles",String.valueOf(roles));

                editor.apply();

                editor.apply();
                Intent intent = new Intent(getApplicationContext(), nav_d.class);
                startActivity(intent);

            }
            else {
                dialog.cancel();
                builder2.setTitle("Invalid phone no. or password");
                //builder1.setMessage("Connect tO N");
                builder2.setCancelable(false);
                builder2.setPositiveButton(
                        "ok",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {

                                mob.setText("");
                                pwd.setText("");
                            }
                        });
                AlertDialog alert12 = builder2.create();
                alert12.show();
            }*/
        }
    }
}
