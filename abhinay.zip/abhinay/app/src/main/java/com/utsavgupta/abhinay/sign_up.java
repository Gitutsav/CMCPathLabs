package com.utsavgupta.abhinay;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Build;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;
public class sign_up extends Activity implements ConnectivityReceiver.ConnectivityReceiverListener {

    EditText mob, pwd;
    Button login;
    ImageButton back;
    TextView forgot;
    AlertDialog.Builder builder1,builder2;
    private ProgressDialog dialog;
    private String message, status;
    private String mob_no = "", pawrd = "";
    String access_token = "", refresh_token = "", token_id = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        checkConnection();
        mob = (EditText) findViewById(R.id.mob);
        //pwd = (EditText) findViewById(R.id.pwd);
        login = (Button) findViewById(R.id.login);
        back = (ImageButton) findViewById(R.id.back);
       // forgot = (TextView) findViewById(R.id.forgot);
        builder2=new AlertDialog.Builder(this);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), login_sign.class));
            }
        });
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                dialog = new ProgressDialog(sign_up.this);
                dialog.setCancelable(false);
                dialog.setMessage("Signing Up , please wait..");
                dialog.show();
              //  Log.d("Login Pressed", "In Login onCLick Listener");
                mob_no = mob.getText().toString().trim();
                //pawrd = pwd.getText().toString().trim();
                // v.vibrate(100);//0.1 sec
                Boolean isconnected = ConnectivityReceiver.isConnected();
                if (mob_no.isEmpty() ) {
                    dialog.cancel();
                    builder1 = new AlertDialog.Builder(view.getContext());
                    builder1.setTitle("Enter Phone no.");
                    //builder1.setMessage("Connect tO N");
                    builder1.setCancelable(false);
                    builder1.setPositiveButton(
                            "ok",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.cancel();
                                }
                            });
                    AlertDialog alert11 = builder1.create();
                    alert11.show();
                } else {
                    //checkConnection();
                    if (isconnected) {
                        //dialog.cancel();
                        // Intent intent = new Intent(LoginActivity.this, BLOCK_nav_d.class);
                        //startActivity(intent);
                        // OnLogin();
                        new JSONTask().execute("https://api-dev.penpencil.xyz/v1/users/register/5bb72f09d7de500de0338d00", mob_no);


                    } else if (isconnected == false) {
                        // dialog.cancel();
                        builder1 = new AlertDialog.Builder(view.getContext());
                        builder1.setTitle("Check Your Internet Connection!!");
                        //builder1.setMessage("Connect tO N");
                        builder1.setCancelable(false);

                        builder1.setPositiveButton(
                                "ok",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        // startActivity(new Intent(view.getContext(),BlockTabbedteacher.class));
                                        dialog.cancel();
                                    }
                                });
                        AlertDialog alert11 = builder1.create();
                        alert11.show();


                    }

                }
            }



        });


    }

    @Override
    public void onNetworkConnectionChanged(boolean isConnected) {

    }

    @Override
    protected void onResume() {
        super.onResume();

        // register connection status listener
        MyApplication.getInstance().setConnectivityListener(this);
    }

    private void checkConnection() {
        boolean isConnected = ConnectivityReceiver.isConnected();
        //showSnack(isConnected);
    }

    private void showSnack(boolean isConnected) {
        String message;
        int color;
        if (isConnected) {
            message = "Good! Connected to Internet";
            color = Color.WHITE;
        } else {
            message = "Sorry! Not connected to internet";
            color = Color.RED;
        }

        Snackbar snackbar = Snackbar
                .make(findViewById(R.id.fab), message, Snackbar.LENGTH_LONG);

        View sbView = snackbar.getView();
        TextView textView = (TextView) sbView.findViewById(android.support.design.R.id.snackbar_text);
        textView.setTextColor(color);
        snackbar.show();
    }

    public class JSONTask extends AsyncTask<String, String, String> {

        @Override
        protected String doInBackground(String... params) {
            HttpURLConnection connection = null;
            BufferedReader reader = null;

            try {
                HttpClient httpClient = new DefaultHttpClient();
                // Creating HTTP Post
                HttpPost httpPost = new HttpPost("https://api-dev.penpencil.xyz/v1/oauth/token");

                List<NameValuePair> nameValuePair = new ArrayList<NameValuePair>(4);
              // nameValuePair.add(new BasicNameValuePair("otp", emaill));
                nameValuePair.add(new BasicNameValuePair("password", pawrd));
               // nameValuePair.add(new BasicNameValuePair("firstName", name));
                nameValuePair.add(new BasicNameValuePair("mobile", mob_no));
                nameValuePair.add(new BasicNameValuePair("email", mob_no));



                // Url Encoding the POST parameters
                try {
                    httpPost.setEntity(new UrlEncodedFormEntity(nameValuePair));
                } catch (UnsupportedEncodingException e) {
                    // writing error to Log
                    e.printStackTrace();
                }
                // Making HTTP Request
                try {
                    HttpResponse response = httpClient.execute(httpPost);
                    String responseBody = EntityUtils.toString(response.getEntity());
                    JSONObject obj = new JSONObject(responseBody);
                    status = obj.getString("success");
                   /* JSONObject data = obj.getJSONObject("data");
                    access_token = data.getString("access_token");
                    refresh_token = data.getString("refresh_token");
                    int expires_in = data.getInt("expires_in");
                    token_id = data.getString("tokenId");
*/
                    return status;

                    // writing response to log
                    // String abc = "124" + status_o + usersCount+website+roles;
                    //Toast.makeText(getApplicationContext(), abc + "1111", Toast.LENGTH_LONG).show();
                    //dialog.cancel();
                    //Log.d("Http Response:", status + "123+abc");
                } catch (ClientProtocolException e) {
                    // writing exception to log
                    e.printStackTrace();
                } catch (IOException e) {
                    // writing exception to log
                    e.printStackTrace();

                } catch (JSONException e) {
                    e.printStackTrace();
                }

                return status;


            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
                try {

                    if (reader != null) {
                        reader.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        }


        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            Toast.makeText(getApplicationContext(),s,Toast.LENGTH_SHORT).show();

            if (s.equals("true")) {
                dialog.cancel();
             /*   SharedPreferences.Editor editor = getSharedPreferences("login_data", MODE_PRIVATE).edit();
                editor.putString("access_token", "");
                editor.putString("refresh_token", "");
                //editor.putInt("expires_in",720000);
                editor.putString("tokenId", "5c449eea1c3ea367a16b1016");

                editor.apply();*/
                Intent intent = new Intent(getApplicationContext(), Dashboard.class);
                startActivity(intent);

            } else {
                dialog.cancel();
                builder2.setTitle("Invalid phone no. or password");
                //builder1.setMessage("Connect tO N");
                builder2.setCancelable(false);
                builder2.setPositiveButton(
                        "ok",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {

                                mob.setText("");
                                pwd.setText("");
                            }
                        });
                AlertDialog alert12 = builder2.create();
                alert12.show();
            }
        }
    }

}
