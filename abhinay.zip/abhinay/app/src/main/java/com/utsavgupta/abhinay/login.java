package com.utsavgupta.abhinay;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Build;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;
public class login extends Activity implements ConnectivityReceiver.ConnectivityReceiverListener {

    EditText mob, pwd;
    Button login;
    ImageButton back;
    TextView forgot;
    AlertDialog.Builder builder1,builder2;
    private ProgressDialog progressdialog;
    private String message, status;
    private String mob_no = "", pawrd = "";
    String access_token = "", refresh_token = "", token_id = "";
    private String status_u,idg,firstName;Boolean is_student;
    String primaryNumber= null,username= null,
            emailg= null,created= null,_id= null,created_p= null,board= null,
            class_p= null,language= null,lastLoginAt= null,programId= null,
            dateOfBirth= null,address= null,primary= null,status_o= null,
            id_o= null,website= null,name= null,enrollmentType= null,id_o_p= null,
            created_o= null;String primarycontact_o="";
    JSONArray exams= null,phones= null,roles = null,phones_o= null,rejectionComments= null;

    int wallet= 0,usersCount=0;
    private String abc,_v;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        checkConnection();
        mob = (EditText) findViewById(R.id.mob);
        pwd = (EditText) findViewById(R.id.pwd);
        login = (Button) findViewById(R.id.login);
        back = (ImageButton) findViewById(R.id.back);
        forgot = (TextView) findViewById(R.id.forgot);
        builder2=new AlertDialog.Builder(this);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), login_sign.class));
            }
        });
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                progressdialog = new ProgressDialog(login.this);
                progressdialog.setCancelable(false);
                progressdialog.setMessage("Fetching data , please wait..");
                progressdialog.show();
                Log.d("Login Pressed", "In Login onCLick Listener");
                mob_no = mob.getText().toString().trim();
                pawrd = pwd.getText().toString().trim();
                // v.vibrate(100);//0.1 sec
                Boolean isconnected = ConnectivityReceiver.isConnected();
                if (mob_no.isEmpty() || pawrd.isEmpty()) {
                    progressdialog.cancel();
                    builder1 = new AlertDialog.Builder(view.getContext());
                    builder1.setTitle("Enter Login Credentials");
                    //builder1.setMessage("Connect tO N");
                    builder1.setCancelable(false);
                    builder1.setPositiveButton(
                            "ok",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.cancel();
                                }
                            });
                    AlertDialog alert11 = builder1.create();
                    alert11.show();
                } else {
                    //checkConnection();
                    if (isconnected) {
                        //dialog.cancel();
                        // Intent intent = new Intent(LoginActivity.this, BLOCK_nav_d.class);
                        //startActivity(intent);
                        // OnLogin();
                        new JSONTask().execute("https://api-dev.penpencil.xyz/v1/oauth/token", mob_no, pawrd);


                    } else if (isconnected == false) {
                       // dialog.cancel();
                        builder1 = new AlertDialog.Builder(view.getContext());
                        builder1.setTitle("Check Your Internet Connection!!");
                        //builder1.setMessage("Connect tO N");
                        builder1.setCancelable(false);

                        builder1.setPositiveButton(
                                "ok",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        // startActivity(new Intent(view.getContext(),BlockTabbedteacher.class));
                                      progressdialog.cancel();
                                    }
                                });
                        AlertDialog alert11 = builder1.create();
                        alert11.show();


                    }

                }
            }



        });


    }

    @Override
    public void onNetworkConnectionChanged(boolean isConnected) {

    }

    @Override
    protected void onResume() {
        super.onResume();

        // register connection status listener
        MyApplication.getInstance().setConnectivityListener(this);
    }

    private void checkConnection() {
        boolean isConnected = ConnectivityReceiver.isConnected();
        //showSnack(isConnected);
    }

    private void showSnack(boolean isConnected) {
        String message;
        int color;
        if (isConnected) {
            message = "Good! Connected to Internet";
            color = Color.WHITE;
        } else {
            message = "Sorry! Not connected to internet";
            color = Color.RED;
        }

        Snackbar snackbar = Snackbar
                .make(findViewById(R.id.fab), message, Snackbar.LENGTH_LONG);

        View sbView = snackbar.getView();
        TextView textView = (TextView) sbView.findViewById(android.support.design.R.id.snackbar_text);
        textView.setTextColor(color);
        snackbar.show();
    }

    public class JSONTask extends AsyncTask<String, String, String> {

        @Override
        protected String doInBackground(String... params) {
            HttpURLConnection connection = null;
            BufferedReader reader = null;

            try {
                HttpClient httpClient = new DefaultHttpClient();
                // Creating HTTP Post
                HttpPost httpPost = new HttpPost("https://api-dev.penpencil.xyz/v1/oauth/token");

                List<NameValuePair> nameValuePair = new ArrayList<NameValuePair>(6);
                nameValuePair.add(new BasicNameValuePair("username", mob_no));
                nameValuePair.add(new BasicNameValuePair("password", pawrd));
                nameValuePair.add(new BasicNameValuePair("client_id", "system-admin"));
                nameValuePair.add(new BasicNameValuePair("client_secret", "KjPXuAVfC5xbmgreETNMaL7z"));
                nameValuePair.add(new BasicNameValuePair("grant_type", "password"));
                nameValuePair.add(new BasicNameValuePair("organizationId", "5bb72f09d7de500de0338d00"));

                // Url Encoding the POST parameters
                try {
                    httpPost.setEntity(new UrlEncodedFormEntity(nameValuePair));
                } catch (UnsupportedEncodingException e) {
                    // writing error to Log
                    e.printStackTrace();
                }
                // Making HTTP Request
                try {
                    HttpResponse response = httpClient.execute(httpPost);
                    String responseBody = EntityUtils.toString(response.getEntity());
                    JSONObject obj = new JSONObject(responseBody);
                    status = obj.getString("success");
                    JSONObject data = obj.getJSONObject("data");
                    access_token = data.getString("access_token");
                    refresh_token = data.getString("refresh_token");
                    int expires_in = data.getInt("expires_in");
                    token_id = data.getString("tokenId");
                    JSONObject user = data.getJSONObject("user");
                    status_u=user.getString("status");
                   // is_student=user.getBoolean("isStudent");
                    idg=user.getString("id");
                    firstName=user.getString("firstName");
                    primaryNumber=user.getString("primaryNumber");
                    username=user.getString("username");
                    emailg=user.getString("email");
                    created=user.getString("created");
                    JSONObject profileId=user.getJSONObject("profileId");
                    exams=profileId.getJSONArray("exams");
                    _id=profileId.getString("_id");
                    created_p=profileId.getString("created");
                    //firstName=user.toString();
                    wallet=profileId.getInt("wallet");
                    dateOfBirth=user.getString("dateOfBirth");
                    phones=user.getJSONArray("phones");
                    address=user.getString("address");
                    primary=user.getString("primary");
                    JSONObject organization = user.getJSONObject("organization");
                    status_o = organization.getString("status");
                    usersCount = organization.getInt("usersCount");
                    id_o=organization.getString("_id");
                    website=organization.getString("website");
                    name=organization.getString("name");
                    enrollmentType=organization.getString("enrolmentType");
                    primarycontact_o=organization.getString("primaryContact");
                    _v=organization.getString("_v");
                    rejectionComments=organization.getJSONArray("rejectionComments");
                    phones_o=organization.getJSONArray("phones");
                    created_o=organization.getString("createdAt");
                    roles=user.getJSONArray("roles");
                    abc=status_u+idg+is_student+firstName+primaryNumber+username+emailg+created+String.valueOf(exams)+_id+
                            created_p+board+class_p+language+lastLoginAt+programId+String.valueOf(wallet)+dateOfBirth+
                            String.valueOf(phones)+address+primary+status_o+String.valueOf(usersCount)+id_o+website+name+
                            enrollmentType+primaryNumber+String.valueOf(rejectionComments)+String.valueOf(phones_o)+
                            created_o+String.valueOf(roles);
                    return status;

                    // writing response to log
                    // String abc = "124" + status_o + usersCount+website+roles;
                    //Toast.makeText(getApplicationContext(), abc + "1111", Toast.LENGTH_LONG).show();
                    //dialog.cancel();
                    //Log.d("Http Response:", status + "123+abc");
                } catch (ClientProtocolException e) {
                    // writing exception to log
                    e.printStackTrace();
                } catch (IOException e) {
                    // writing exception to log
                    e.printStackTrace();

                } catch (JSONException e) {
                    e.printStackTrace();
                }

                return status;


            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
                try {

                    if (reader != null) {
                        reader.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        }


        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            Toast.makeText(getApplicationContext(),primaryNumber+username+emailg+created+exams+_id+created_p+wallet+
                    dateOfBirth+phones+address+primary+roles
                    +status_o+usersCount+id_o+website+name+enrollmentType+primarycontact_o+_v
                    +rejectionComments+phones_o+created_o,Toast.LENGTH_SHORT).show();

            if (s.equals("true")) {
                progressdialog.cancel();

                SharedPreferences.Editor editor = getSharedPreferences("login_data2", MODE_PRIVATE).edit();
                editor.putString("access_token", access_token);
                editor.putString("status_u",status_u);
               // editor.putBoolean("user_isStudent",is_student);
                editor.putString("user_id",idg);
                editor.putString("user_firstName",firstName);
                editor.putString("user_primaryNumber",primaryNumber);
                editor.putString("user_username",username);
                editor.putString("user_email",emailg);
                editor.putString("user_created",created);
                editor.putString("exams", String.valueOf(exams));
                editor.putString("profile_id",_id);
                editor.putString("profile_created",created_p);
                editor.putString("profile_board",board);
                editor.putString("profile_class",class_p);
                editor.putString("profile_language",language);
                editor.putString("profile_lastLoginAt",lastLoginAt);
                editor.putString("profile_programId",programId);
                editor.putString("profile_wallet", String.valueOf(wallet));
                editor.putString("dateOfBirth",dateOfBirth);
                editor.putString("phones", String.valueOf(phones));
                editor.putString("address",address);
                editor.putString("primary",primary);
                editor.putString("organization_status",status_o);
                //editor.putString("status","");
                editor.putString("organization_usersCount", String.valueOf(usersCount));
                editor.putString("organization_id",id_o);
                editor.putString("organization_website",website);
                editor.putString("organization_name",name);
                editor.putString("organization_enrolmentType",enrollmentType);
                editor.putString("organization_primaryContact_id",primaryNumber);
                editor.putString("organization_rejectionComments", String.valueOf(rejectionComments));
                editor.putString("organization_phones", String.valueOf(phones_o));
                editor.putString("organization_created",created_o);
                editor.putString("roles",String.valueOf(roles));

                editor.apply();

                editor.apply();
                Intent intent = new Intent(getApplicationContext(), nav_d.class);
                startActivity(intent);

            }
            else {
                progressdialog.cancel();
                builder2.setTitle("Invalid phone no. or password");
                //builder1.setMessage("Connect tO N");
                builder2.setCancelable(false);
                builder2.setPositiveButton(
                        "ok",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {

                                mob.setText("");
                                pwd.setText("");
                            }
                        });
                AlertDialog alert12 = builder2.create();
                alert12.show();
            }
            }
        }
    }
