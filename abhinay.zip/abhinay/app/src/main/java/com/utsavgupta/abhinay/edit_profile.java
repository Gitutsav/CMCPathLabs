package com.utsavgupta.abhinay;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class edit_profile extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);
    }
}
