package com.utsavgupta.abhinay;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.net.HttpURLConnection;

public class profile extends AppCompatActivity {
ImageButton back;
    private String status;String access_token="",firstName="",primaryNumber,email="";
    TextView name,phone,emaill,heading;ImageView edit_profile,change_password;
    SharedPreferences sharedPreferences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        back=(ImageButton)findViewById(R.id.back);
        name=(TextView)findViewById(R.id.name);
        phone=(TextView)findViewById(R.id.phone);
        emaill=(TextView)findViewById(R.id.email);
        heading=(TextView)findViewById(R.id.heading);
        edit_profile=(ImageView)findViewById(R.id.edit);
        change_password=(ImageView)findViewById(R.id.change);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(profile.this,nav_d.class);
                startActivity(intent);
            }
        });
        edit_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(profile.this,edit_profile.class);
                startActivity(intent);
            }
        });
        change_password.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(profile.this,change_password.class);
                startActivity(intent);
            }
        });
        SharedPreferences prefs = getSharedPreferences("login_data2", MODE_PRIVATE);
        access_token = prefs.getString("access_token", null);
        new JSONTaskResendOtp().execute();
    }

    public class JSONTaskResendOtp extends AsyncTask<String, String, String> {

        @Override
        protected String doInBackground(String... params) {
            HttpURLConnection connection = null;
            BufferedReader reader = null;


            try {
                DefaultHttpClient httpClient = new DefaultHttpClient();

                /*httpClient.DefaultRequestHeaders.Authorization
                        = new AuthenticationHeaderValue("Bearer", "d808774440e702689942c7970cd1fc1000546a064288b2dfbd7aadf322cea044");*/
                // Creating HTTP Post
                HttpGet httpPost = new HttpGet("https://api-dev.penpencil.xyz/v1/users/self");
               // httpPost.setHeader("A");

                httpPost.setHeader("Authorization","Bearer "+access_token);

                //List<NameValuePair> nameValuePair = new ArrayList<NameValuePair>(1);
                // nameValuePair.add(new BasicNameValuePair("otp", otpp));


                // Url Encoding the POST parameters

                // Making HTTP Request
                try {
                    HttpResponse response = httpClient.execute(httpPost);
                    String responseBody = EntityUtils.toString(response.getEntity());
                    JSONObject obj = new JSONObject(responseBody);
                    status = obj.getString("success");
                    JSONObject data=obj.getJSONObject("data");
                    firstName =data.getString("firstName");
                    primaryNumber=data.getString("primaryNumber");
                    email=data.getString("email");



                    return responseBody;

                    // writing response to log
                    // String abc = "124" + status_o + usersCount+website+roles;
                    //Toast.makeText(getApplicationContext(), abc + "1111", Toast.LENGTH_LONG).show();
                    //dialog.cancel();
                    //Log.d("Http Response:", status + "123+abc");
                } catch (ClientProtocolException e) {
                    // writing exception to log
                    e.printStackTrace();
                } catch (IOException e) {
                    // writing exception to log
                    e.printStackTrace();

                } catch (JSONException e) {
                    e.printStackTrace();
                }

                return status;


            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
                try {

                    if (reader != null) {
                        reader.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
             Toast.makeText(getApplicationContext(),s,Toast.LENGTH_SHORT).show();
             name.setText(firstName);
             phone.setText(primaryNumber);
             emaill.setText(email);
             heading.setText(firstName);

        }
    }
}
