import 'package:flutter/material.dart';
import 'package:flutter_trading_app_ui/graph_page.dart';
class Trades extends StatefulWidget {
  @override
  _TradesState createState() => _TradesState();
}

class _TradesState extends State<Trades> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        backgroundColor: Colors.black,
        title: Text("Trades",style: TextStyle(color: Colors.white)),
        ),
      body: Stack(
        children: <Widget>[
          Column(
            children: <Widget>[
              FlatButton(
                child: Card(
                  margin: const EdgeInsets.only(top: 15.0),
                  child: Container(
                    padding: const EdgeInsets.all(10.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Text("BTC-ETH",style: TextStyle(fontSize: 20)),
                        Column(
                          children: <Widget>[
                            Text("270",style: TextStyle(fontSize: 20)),
                            Text("5.1%"),
                          ],
                        )
                      ],
                    ),
                  ),
                ),
                onPressed: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>GraphPage()));
                },
              ),
              new Padding(
                  padding: EdgeInsets.all(8.0),
                  child: new Divider()
              ),
              FlatButton(
                child:Card(
                  child: Container(
                    padding: const EdgeInsets.all(10.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Text("BTC-ADA",style: TextStyle(fontSize: 20)),
                        Column(
                          children: <Widget>[
                            Text("913",style: TextStyle(fontSize: 20)),
                            Text("-0.22%"),
                          ],
                        )
                      ],
                    ),
                  ),
                ),
                onPressed: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>GraphPage()));
                },
              ),
              new Padding(
                  padding: EdgeInsets.all(2.0),
                  child: new Divider()
              ),
              FlatButton(
                child:Card(
                  child: Container(
                    padding: const EdgeInsets.all(10.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Text("BTC-ADA",style: TextStyle(fontSize: 20)),
                        Column(
                          children: <Widget>[
                            Text("913",style: TextStyle(fontSize: 20)),
                            Text("-0.22%"),
                          ],
                        )
                      ],
                    ),
                  ),
                ),
                onPressed: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>GraphPage()));
                },
              ),
              new Padding(
                  padding: EdgeInsets.all(8.0),
                  child: new Divider()
              ),
            ],
          ),

        ],
      ),
    );
  }
}
