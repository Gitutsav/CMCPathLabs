String readhasuraBTCData = """
query get_tickers {
  miniTicker(limit: 100, where: {symbol: {_like:"%BTC"}}, order_by: {eventTime: desc}) {
    symbol
    eventTime
    close
    volume
  }
}

"""
    .replaceAll('\n', ' ');

String readhasuraBNBData = """
query get_tickers {
  miniTicker(limit: 100, where: {symbol: {_like:"%BNB"}}, order_by: {eventTime: desc}) {
    symbol
    eventTime
    close
    volume
  }
}

"""
    .replaceAll('\n', ' ');
String readhasuraETHData = """
query get_tickers {
  miniTicker(limit: 100, where: {symbol: {_like:"%ETH"}}, order_by: {eventTime: desc}) {
    symbol
    eventTime
    close
    volume
  }
}

"""
    .replaceAll('\n', ' ');
String readhasuraUSDTData = """
query get_tickers {
  miniTicker(limit: 100, where: {symbol: {_like:"%USDT"}}, order_by: {eventTime: desc}) {
    symbol
    eventTime
    close
    volume
  }
}

"""
    .replaceAll('\n', ' ');