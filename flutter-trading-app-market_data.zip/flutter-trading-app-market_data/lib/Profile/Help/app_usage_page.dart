import 'package:flutter/material.dart';

class AppUsagePage extends StatefulWidget {
  @override
  _AppUsagePageState createState() => _AppUsagePageState();
}

class _AppUsagePageState extends State<AppUsagePage> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
