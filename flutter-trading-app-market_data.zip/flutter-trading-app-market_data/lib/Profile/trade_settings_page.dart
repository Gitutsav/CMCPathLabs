import 'package:flutter/material.dart';

class TradeSettingsPage extends StatefulWidget {
  @override
  _TradeSettingsPageState createState() => _TradeSettingsPageState();
}

class _TradeSettingsPageState extends State<TradeSettingsPage> {

  final _formKey = GlobalKey<FormState>();

  var _defaultProfitSwitchValue= false,
      _defaultStopLossSwitchValue= false,
      _defaultTrailingBuySwitchValue= false,
      _defaultTrailingStopSwitchValue= false;

  var _defaultProfitController = TextEditingController(),
      _defaultStopLossController = TextEditingController(),
      _defaultTrailingBuyController = TextEditingController(),
      _defaultTrailingStopController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    bool _switchValue = false;

    return Form(
      key: _formKey,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.black,
          title: Text("Trade Settings", style: TextStyle(color: Colors.white)),
        ),
        body: Stack(
          children: <Widget>[
            Container(
              child: Column(
                children: <Widget>[
                  Container(
                    margin: const EdgeInsets.only(
                        top: 10.0, left: 20.0, right: 10.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Container(
                          child: Text("Default Profit",
                              style: TextStyle(fontSize: 20)),
                        ),
                        Switch(
                          value: _defaultProfitSwitchValue,
                          onChanged: (bool value) {
                            setState(() {
                              _defaultProfitSwitchValue = value;
                            });
                          },
                        )
                      ],
                    ),
                  ),

                  _defaultProfitSwitchValue? new Container(
                    margin: const EdgeInsets.only(left: 20),

                    child: Row(

                      children: <Widget>[

                        Container(
                          width:100,
                          decoration: new BoxDecoration(
                            borderRadius:
                            new BorderRadius.all(new Radius.circular(5.0)),
                            border: new Border.all(
                              color: Colors.grey,
                              width: 1.0,
                            ),
                          ),
                          child: TextFormField(
                            autofocus: true,
                            validator: (value) {
                              if (value.isEmpty) {
                                return 'Enter something';
                              }
                            },
                            controller: _defaultProfitController,
                            keyboardType: TextInputType.number,
                            style: TextStyle(fontSize: 20, color: Colors.black),
                          ),
                        ),

                        Container(
                            padding: const EdgeInsets.only(left: 5),
                            child: Text('%',style: TextStyle(fontSize: 26,fontWeight: FontWeight.bold),))
                      ],
                    ),
                  ): new Container(),

                  Container(
                    margin: const EdgeInsets.only(
                        top: 10.0, left: 20.0, right: 10.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Container(
                          child: Text("Default Stop Loss",
                              style: TextStyle(fontSize: 20)),
                        ),
                        Switch(
                          value: _defaultStopLossSwitchValue,
                          onChanged: (bool value) {
                            setState(() {
                              _defaultStopLossSwitchValue = value;
                            });
                          },
                        )
                      ],
                    ),
                  ),

                  _defaultStopLossSwitchValue? new Container(
                    margin: const EdgeInsets.only(left: 20),

                    child: Row(

                      children: <Widget>[

                        Container(
                          width:100,
                          decoration: new BoxDecoration(
                            borderRadius:
                            new BorderRadius.all(new Radius.circular(5.0)),
                            border: new Border.all(
                              color: Colors.grey,
                              width: 1.0,
                            ),
                          ),
                          child: TextFormField(
                            autofocus: true,
                            validator: (value) {
                              if (value.isEmpty) {
                                return 'Enter something';
                              }
                            },
                            controller: _defaultStopLossController,
                            keyboardType: TextInputType.number,
                            style: TextStyle(fontSize: 20, color: Colors.black),
                          ),
                        ),

                        Container(
                            padding: const EdgeInsets.only(left: 5),
                            child: Text('%',style: TextStyle(fontSize: 26,fontWeight: FontWeight.bold),))
                      ],
                    ),
                  ): new Container(),


                  Container(
                    margin: const EdgeInsets.only(
                        top: 10.0, bottom: 10.0, left: 20.0, right: 10.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Container(
                          child: Text("Default Trailing Buy",
                              style: TextStyle(fontSize: 20)),
                        ),
                        Switch(
                          value: _defaultTrailingBuySwitchValue,
                          onChanged: (bool value) {
                            setState(() {
                              _defaultTrailingBuySwitchValue = value;
                            });
                          },
                        )
                      ],
                    ),
                  ),

                  _defaultTrailingBuySwitchValue? new Container(
                    margin: const EdgeInsets.only(left: 20),

                    child: Row(

                      children: <Widget>[

                        Container(
                          width:100,
                          decoration: new BoxDecoration(
                            borderRadius:
                            new BorderRadius.all(new Radius.circular(5.0)),
                            border: new Border.all(
                              color: Colors.grey,
                              width: 1.0,
                            ),
                          ),
                          child: TextFormField(
                            autofocus: true,
                            validator: (value) {
                              if (value.isEmpty) {
                                return 'Enter something';
                              }
                            },
                            controller: _defaultTrailingBuyController,
                            keyboardType: TextInputType.number,
                            style: TextStyle(fontSize: 20, color: Colors.black),
                          ),
                        ),

                        Container(
                            padding: const EdgeInsets.only(left: 5),
                            child: Text('%',style: TextStyle(fontSize: 26,fontWeight: FontWeight.bold),))
                      ],
                    ),
                  ): new Container(),


                  Container(
                    margin: const EdgeInsets.only(
                        top: 10.0, bottom: 10.0, left: 20.0, right: 10.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Container(
                          child: Text("Default Trailing Stop Loss",
                              style: TextStyle(fontSize: 20)),
                        ),
                        Switch(
                          value: _defaultTrailingStopSwitchValue,
                          onChanged: (bool value) {
                            setState(() {
                              _defaultTrailingStopSwitchValue = value;
                            });
                          },
                        )
                      ],
                    ),
                  ),

                  _defaultTrailingStopSwitchValue? new Container(
                    margin: const EdgeInsets.only(left: 20),

                    child: Row(

                      children: <Widget>[

                        Container(
                          width:100,
                          decoration: new BoxDecoration(
                            borderRadius:
                            new BorderRadius.all(new Radius.circular(5.0)),
                            border: new Border.all(
                              color: Colors.grey,
                              width: 1.0,
                            ),
                          ),
                          child: TextFormField(
                            autofocus: true,
                            validator: (value) {
                              if (value.isEmpty) {
                                return 'Enter something';
                              }
                            },
                            controller: _defaultTrailingStopController,
                            keyboardType: TextInputType.number,
                            style: TextStyle(fontSize: 20, color: Colors.black),
                          ),
                        ),

                        Container(
                            padding: const EdgeInsets.only(left: 5),
                            child: Text('%',style: TextStyle(fontSize: 26,fontWeight: FontWeight.bold),))
                      ],
                    ),
                  ): new Container(),




                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
