import 'package:flutter/material.dart';
import 'package:flutter_trading_app_ui/auth/login_page.dart';
import 'dart:async';
import 'main.dart';
//import 'package:flutter_app/core/init.dart';
//import 'package:flutter_app/core/cognito.dart' show UserState;

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Timer(Duration(seconds: 2), () => _launchMianPage());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: <Widget>[
          Container(
            decoration: BoxDecoration(
              color: Colors.black,
            ),
          ),
        ],
      ), //Stack
    );
  }

  _launchMianPage() {
//    initialize().then((userStateDetails) {
//      print(userStateDetails);
//      if (userStateDetails.userState == UserState.SIGNED_IN) {
//        ///show home page
//        Navigator.pushReplacement(
//          context,
//          MaterialPageRoute(builder: (context) => Main(userStateDetails)),
//        ).catchError((e) {
//          print(e);
//        });
//      } else {
//        ///show login page
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => LoginScreen()),
    ).catchError((e) {
      print(e);
    });
//      }
//    }).catchError((e) {
//      print(e);
//    });
  }
}
