import 'package:flutter/material.dart';
import 'package:flutter_trading_app_ui/Profile/profile_page.dart';
import 'package:flutter_trading_app_ui/market_data_page.dart';
import 'package:flutter_trading_app_ui/trades.dart';
import 'package:flutter_trading_app_ui/wallet_page.dart';
class SwitcherPage extends StatefulWidget {
  @override
  _SwitcherPageState createState() => _SwitcherPageState();
}

class _SwitcherPageState extends State<SwitcherPage> {

  int _currentIndex = 0;
  final List<Widget> _children = [
    MarketDataPage(),
    Trades(),
    WalletPage(),
    ProfilePage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _children[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        currentIndex: _currentIndex,
        onTap:onTabTapped,// this will be set when a new tab is tapped
        items: [
          BottomNavigationBarItem(
            icon: new Icon(Icons.attach_money),
            title: new Text('Markets'),
          ),
          BottomNavigationBarItem(
            icon: new Icon(Icons.show_chart),
            title: new Text('Trades'),
          ),
          BottomNavigationBarItem(
            icon: new Icon(Icons.account_balance_wallet),
            title: new Text('Wallet'),
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            title: Text('Profile'),
          )
        ],
      ),
    );
  }
  void onTabTapped(int index) {
    setState(() {
      _currentIndex = index;
    });
  }
}
