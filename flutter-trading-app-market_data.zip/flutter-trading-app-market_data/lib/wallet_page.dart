import 'package:flutter/material.dart';
class WalletPage extends StatefulWidget {


  @override
  _WalletPageState createState() => _WalletPageState();
}

class _WalletPageState extends State<WalletPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          automaticallyImplyLeading: false,
        backgroundColor: Colors.black,
        title: Text("Wallet",style: TextStyle(color: Colors.white)),
    ),
      body: Stack(
        children: <Widget>[
          Container(
            child: Column(
              children: <Widget>[
                Container(
                  padding: const EdgeInsets.only(top: 5.0,left: 20.0,bottom: 5.0),
                  alignment: Alignment(-1.0, 1),
                  child: Text("ESTIMATED VALUE",style: TextStyle(fontSize:20,fontWeight: FontWeight.bold)),
                ),
                Container(
                  padding: const EdgeInsets.only(left: 20.0,bottom: 5.0,right: 10.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Text("0.13449396",style: TextStyle(fontSize: 18)),
                      Text("869.62"+"USD",style: TextStyle(fontSize: 18)),
                    ],
                  ),
                ),
                new Padding(
                    padding: EdgeInsets.all(8.0),
                    child: new Divider()
                ),
                Container(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: <Widget>[
                      Text("COIN",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 18)),
                      Text("HOLDINGS",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 18)),
                      Text("PRICE",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 18)),
                    ],
                  ),
                ),
                new Padding(
                    padding: EdgeInsets.all(8.0),
                    child: new Divider()
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
