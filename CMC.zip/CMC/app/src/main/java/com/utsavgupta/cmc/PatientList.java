package com.utsavgupta.cmc;

public class PatientList {
}
